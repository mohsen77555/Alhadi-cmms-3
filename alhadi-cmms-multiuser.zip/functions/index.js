/* المرحلة 4 (خادم) — إشعار الفني عند إسناده لأمر عمل
   النشر: داخل functions/: npm i firebase-admin firebase-functions ثم firebase deploy --only functions
   (يتطلب خطة Blaze) */
const { onDocumentWritten } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");
initializeApp();

exports.notifyAssignment = onDocumentWritten("cmms/main/records/workOrders/items/{woId}", async (event) => {
  const before = event.data?.before?.data() || {};
  const after = event.data?.after?.data();
  if (!after) return; // حذف
  const prevIds = new Set(before._cmmsAssignedTechIds || []);
  const newIds = (after._cmmsAssignedTechIds || []).filter((id) => !prevIds.has(id));
  if (!newIds.length) return;

  const db = getFirestore();
  // المستخدمون المرتبطون بهؤلاء الفنيين
  const users = await db.collection("users").where("technicianId", "in", newIds.slice(0, 10)).get();
  const tokens = [];
  users.forEach((u) => (u.data().fcmTokens || []).forEach((t) => tokens.push(t)));
  if (!tokens.length) return;

  await getMessaging().sendEachForMulticast({
    tokens,
    notification: {
      title: "أمر عمل جديد مُسند إليك",
      body: (after.number || "") + " — " + (after.title || ""),
    },
    data: { woId: event.params.woId, type: "wo-assigned" },
  });
});
