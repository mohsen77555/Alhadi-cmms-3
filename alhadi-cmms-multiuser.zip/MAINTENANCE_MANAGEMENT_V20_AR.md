# تحديث v20 — Maintenance Management / Work Execution

تم تطبيق المتطلبات الجديدة داخل تطبيق CMMS:

## الشاشات الجديدة
- إضافة شاشة **إدارة الصيانة** من قائمة المزيد.
- تبويبات: الملخص، التدفق، التخطيط، الإرسال، تنفيذ الفني، المراجعة، القواعد، التقارير، الكيانات.
- زر إنشاء نموذج كامل: ELA-01، CC-01، SFN-01، WO-1001، Bearing Lubrication، Bucket Elevator Monthly PM، Silo Fan PM.

## دورة أمر العمل
- Draft / Released / Ready / In Progress / Pending Supervisor Review / Closed.
- حالات إضافية: On Hold، Waiting Material، Waiting Approval، Canceled، Rejected، Past Due، Exception.
- منع الإغلاق النهائي بدون اعتماد المشرف.
- منع بدء العمل قبل إكمال السلامة إذا كانت مطلوبة.
- منع طلب الإكمال إذا لم تكتمل العمليات أو الساعات أو المواد أو العطل أو الصور أو الملاحظات المطلوبة.

## تنفيذ الفني
- شاشة الإسناد والجدولة داخل أمر العمل.
- إسناد فني رئيسي، فريق، مركز عمل، مورد خارجي، وتواريخ الجدولة.
- ملاحظات الإكمال والنتيجة قبل Submit Completion.
- دعم صور: قبل، أثناء، بعد، عطل، قطعة غيار.

## القواعد المطبقة
- No Work Order without Asset.
- No PM Work Order without Maintenance Program or Work Definition.
- No Work Order release without material availability check.
- No work order without technicians assign.
- No technician completion without checklist.
- No final close without supervisor approval.
- No material cost without material transaction.
- No labor cost without labor transaction.
- No failure analysis without asset.
- No status change without audit log.
- No start without safety checklist if required.
- No completion without finishing all required operations.
- No corrective work completion without failure data.
- No photo-required work completion without photos.
- Every execution action creates audit history.

## كيانات البيانات المضافة
- WorkRequestAttachments
- StandardOperationSteps
- WorkDefinitionOperations / Steps / Materials / Resources / Versions
- MaintenanceProgramAssets / Groups / Forecasts
- WorkOrderOperations / Steps / Materials / Resources / Assignments / StatusHistory / Attachments / Photos / Failures / Exceptions / Costs / Approvals
- DispatchListViews
- TechnicianTasks
- WorkOrderExecutionSessions
- WorkOrderOperationTransactions
- WorkOrderLaborTransactions
- WorkOrderMaterialUsage
- WorkOrderMaterialReturns
- WorkOrderFailureRecords
- WorkOrderInspectionResults
- WorkOrderSafetyChecklists
- WorkOrderChecklistAnswers
- WorkOrderCompletionRequests
- WorkOrderSupervisorReviews
- WorkOrderExecutionHistory

## Firebase
- تم تحديث `firebaseCmms.ts` ليحفظ الكيانات الجديدة كمستندات Firestore مستقلة.
- تم تحديث `firestore.rules` للسماح للفنيين بكتابة سجلات التنفيذ الخاصة بالعمل، وللمخزن بكتابة سجلات المواد.

بعد تثبيت APK الجديد افتح: المزيد → إدارة الصيانة → + إنشاء نموذج إدارة الصيانة الكامل.
