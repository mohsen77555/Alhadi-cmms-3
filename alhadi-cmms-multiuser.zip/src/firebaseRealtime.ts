/* المرحلة 1 — المزامنة اللحظية لكل كيانات CMMS
   اشتراك onSnapshot على records/{entity}/items + المفردات في meta.
   آمن من الحلقات: الدمج الوارد يطابق المحفوظ فلا يولّد كتابة عكسية. */
import { collection, doc, onSnapshot, type Firestore } from "firebase/firestore";
import type { CmmsFirebaseServices } from "./firebaseCmms";

const WORKSPACE = "main";
const recordsCol = (fs: Firestore, entity: string) =>
  collection(fs, "cmms", WORKSPACE, "records", entity, "items");
const singletonDoc = (fs: Firestore, key: string) =>
  doc(fs, "cmms", WORKSPACE, "meta", "singleton-" + key);

function stripMeta(row: any) {
  const out: any = {};
  for (const k of Object.keys(row)) if (!k.startsWith("_cmms") && !k.startsWith("_updated")) out[k] = row[k];
  return out;
}

/** يشترك في كل الكيانات. يعيد دالة إلغاء واحدة.
 *  onEntity(entity, rows)  — مصفوفة كاملة مرتبة حسب _cmmsOrder
 *  onSingleton(key, value) — للمفردات مثل settings */
export function subscribeCmmsRealtime(
  services: CmmsFirebaseServices,
  entityKeys: string[],
  onEntity: (entity: string, rows: any[]) => void,
  onSingleton?: (key: string, value: any) => void,
  singletonKeys: string[] = ["settings"],
): () => void {
  const fs = services.firestore;
  const unsubs: Array<() => void> = [];

  for (const entity of entityKeys) {
    unsubs.push(onSnapshot(recordsCol(fs, entity), (snap) => {
      /* تجاهل اللقطات الناتجة عن كتاباتنا المحلية قيد الإرسال لتقليل الوميض */
      if (snap.metadata.hasPendingWrites) return;
      const rows: any[] = [];
      snap.forEach((d) => {
        const data: any = d.data();
        rows.push({ __o: typeof data?._cmmsOrder === "number" ? data._cmmsOrder : 999999, ...stripMeta(data) });
      });
      rows.sort((a, b) => Number(a.__o) - Number(b.__o));
      onEntity(entity, rows.map(({ __o, ...r }) => r));
    }, (err) => console.warn("realtime:" + entity, err)));
  }

  if (onSingleton) for (const key of singletonKeys) {
    unsubs.push(onSnapshot(singletonDoc(fs, key), (snap) => {
      if (snap.metadata.hasPendingWrites || !snap.exists()) return;
      onSingleton(key, (snap.data() as any)?.value ?? null);
    }, (err) => console.warn("realtime:singleton:" + key, err)));
  }

  return () => unsubs.forEach((u) => { try { u(); } catch {} });
}
