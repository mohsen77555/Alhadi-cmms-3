/* المرحلة 3 — QR للأصول وباركود للأصناف
   متطلبات: npm i qrcode html5-qrcode && npm i -D @types/qrcode */
import QRCode from "qrcode";

export const ASSET_QR_PREFIX = "CMMS-ASSET:";
export const ITEM_QR_PREFIX = "CMMS-ITEM:";

export const assetQrPayload = (assetId: string) => ASSET_QR_PREFIX + assetId;
export const parseQr = (text: string) => {
  if (text.startsWith(ASSET_QR_PREFIX)) return { type: "asset" as const, id: text.slice(ASSET_QR_PREFIX.length) };
  if (text.startsWith(ITEM_QR_PREFIX)) return { type: "item" as const, id: text.slice(ITEM_QR_PREFIX.length) };
  return null;
};

/** dataURL لرمز QR (للعرض أو الطباعة) */
export const qrDataUrl = (payload: string) =>
  QRCode.toDataURL(payload, { margin: 1, width: 280, errorCorrectionLevel: "M" });

/** يفتح نافذة طباعة ملصقات للأصول المحددة */
export async function printAssetLabels(assets: Array<{ id: string; number: string; name: string; location?: string }>) {
  const cells = await Promise.all(assets.map(async (a) => {
    const img = await qrDataUrl(assetQrPayload(a.id));
    return `<div class="lbl"><img src="${img}"/><div class="n">${a.number}</div><div class="t">${a.name}</div><div class="l">${a.location || ""}</div></div>`;
  }));
  const w = window.open("", "_blank"); if (!w) return;
  w.document.write(`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>
    body{font-family:sans-serif;display:flex;flex-wrap:wrap;gap:8mm;padding:8mm}
    .lbl{width:50mm;border:1px solid #000;border-radius:2mm;padding:3mm;text-align:center;page-break-inside:avoid}
    img{width:38mm;height:38mm}.n{font-weight:800;font-size:14pt}.t{font-size:9pt}.l{font-size:8pt;color:#555}
  </style></head><body>${cells.join("")}<script>onload=()=>print()</script></body></html>`);
  w.document.close();
}

/** ماسح الكاميرا — استدعِ start داخل عنصر بمعرّف elementId، وأوقفه بالقيمة المعادة */
export async function startQrScanner(elementId: string, onResult: (parsed: { type: "asset" | "item"; id: string }) => void) {
  const { Html5Qrcode } = await import("html5-qrcode");
  const scanner = new Html5Qrcode(elementId);
  await scanner.start({ facingMode: "environment" }, { fps: 10, qrbox: 220 }, (text) => {
    const p = parseQr(text);
    if (p) { onResult(p); scanner.stop().catch(() => {}); }
  }, () => {});
  return () => scanner.stop().catch(() => {});
}
