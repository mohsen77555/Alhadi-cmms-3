/* المرحلة 4 (عميل) — تسجيل رمز FCM بعد الدخول وحفظه في users/{uid}.fcmTokens */
import { getMessaging, getToken, onMessage } from "firebase/messaging";
import { doc, setDoc, arrayUnion } from "firebase/firestore";
import type { CmmsFirebaseServices } from "./firebaseCmms";

const VAPID_KEY = (import.meta as any).env?.VITE_FCM_VAPID_KEY || ""; // من Console > Cloud Messaging > Web Push

export async function registerPush(services: CmmsFirebaseServices, uid: string) {
  if (!VAPID_KEY || !("Notification" in window)) return null;
  if ((await Notification.requestPermission()) !== "granted") return null;
  const messaging = getMessaging(services.app);
  const token = await getToken(messaging, { vapidKey: VAPID_KEY });
  if (!token) return null;
  await setDoc(doc(services.firestore, "users", uid),
    { fcmTokens: arrayUnion(token), updatedAtIso: new Date().toISOString() }, { merge: true });
  onMessage(messaging, (m) => {
    /* إشعار داخل التطبيق وهو مفتوح */
    try { new Notification(m.notification?.title || "CMMS", { body: m.notification?.body || "" }); } catch {}
  });
  return token;
}
