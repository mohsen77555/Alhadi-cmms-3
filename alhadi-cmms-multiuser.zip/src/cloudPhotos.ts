/* المرحلة 2 — الصور إلى Cloud Storage بدل base64 داخل المستندات */
import { getStorage, ref, uploadString, getDownloadURL, deleteObject } from "firebase/storage";
import type { CmmsFirebaseServices } from "./firebaseCmms";

const WORKSPACE = "main";
const pathFor = (entity: string, id: string, ext = "jpg") =>
  `cmms/${WORKSPACE}/photos/${entity}/${id}.${ext}`;

/** يرفع dataURL ويعيد {path,url} لتخزينهما في السجل بدل base64 */
export async function uploadPhoto(services: CmmsFirebaseServices, entity: string, id: string, dataUrl: string) {
  const storage = getStorage(services.app);
  const ext = dataUrl.startsWith("data:image/png") ? "png" : "jpg";
  const r = ref(storage, pathFor(entity, id, ext));
  await uploadString(r, dataUrl, "data_url");
  const url = await getDownloadURL(r);
  return { path: r.fullPath, url };
}

export async function deletePhoto(services: CmmsFirebaseServices, path: string) {
  try { await deleteObject(ref(getStorage(services.app), path)); } catch {}
}

/** ترحيل صور أمر عمل قديمة (base64) إلى Storage — استدعِها مرة لكل أمر */
export async function migrateWoPhotos(services: CmmsFirebaseServices, wo: any) {
  const photos = wo.photos || [];
  const out: any[] = [];
  for (const p of photos) {
    if (p.url && p.path) { out.push(p); continue; }              // مرحَّلة مسبقًا
    if (typeof p.data === "string" && p.data.startsWith("data:")) {
      const { path, url } = await uploadPhoto(services, "workOrders/" + wo.id, p.id || String(Math.random()).slice(2, 9), p.data);
      const { data, ...rest } = p;
      out.push({ ...rest, path, url });
    } else out.push(p);
  }
  return out;   // خزّنها في update("workOrders", wo.id, { photos: out })
}
